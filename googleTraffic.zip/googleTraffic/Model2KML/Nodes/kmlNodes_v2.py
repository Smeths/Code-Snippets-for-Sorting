# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd

# opening the node data
nodeData = pd.read_csv('nodeData.csv') 

# defining styles
doc = KML.Document(
        KML.name("gx:AnimatedUpdate example"),
        KML.Style(
            KML.IconStyle(
                KML.scale(1.0),
                KML.Icon(
                    KML.href("http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"),
                ),
                id="mystyle"
            ),
            id="pushpin"
        )
    )

# looping over the rows in the dataframe
for index, row in nodeData.iterrows():
    nodeNumStr = str(row[0])
    latlon = OSGB36toWGS84(row[3],row[4])
    latlonStr = str(latlon[1]) + "," + str(latlon[0])
    point = KML.Placemark(
                     KML.name(nodeNumStr),
                     KML.styleUrl("#pushpin"),
                     KML.Point(KML.coordinates(latlonStr))
                  )
    if index == 0:
        fld = KML.Folder(point)
    else:
        fld.append(point)

# appending folder to document
doc.append(fld)

kmlDoc = KML.kml(doc)
print(etree.tostring(kmlDoc, pretty_print=True).decode())




