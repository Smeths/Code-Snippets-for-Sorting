from bng_to_latlon import OSGB36toWGS84
print(OSGB36toWGS84(414677.6451,290247.5709))

