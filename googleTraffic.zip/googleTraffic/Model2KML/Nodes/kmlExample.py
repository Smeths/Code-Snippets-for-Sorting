from pykml.factory import KML_ElementMaker as KML
name_object = KML.name("Hello World!")
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
pm1 = KML.Placemark(
                 KML.name("Hello World!"),
                 KML.Point(
                 KML.coordinates("-64.5253,18.4607")
                )
           )
from lxml import etree
print(etree.tostring(pm1, pretty_print=True).decode("utf-8"))