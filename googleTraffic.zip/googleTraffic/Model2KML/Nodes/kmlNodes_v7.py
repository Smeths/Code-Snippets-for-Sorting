# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd
import math

# function for linear interpolation
def linterp(minp, maxp,n,i):
    return (minp*(n-i) + maxp*i)/n

n = 101 # number of point sizes
minScale = 0.5
maxScale = 1.5

# opening the node data
nodeData = pd.read_csv('nodeData.csv')
datamin = math.floor(min(nodeData.iloc[:,2])) - 1
datamax = math.ceil(max(nodeData.iloc[:,2])) + 1
breakpoints = [linterp(datamin,datamax,n,i) for i in range(n+1)]

# function for point size
def size2id(sizeVar):
    for i, breakpoint in enumerate(breakpoints):
        if sizeVar >= breakpoint and sizeVar <= breakpoints[i+1]:
            pid = linterp(minScale,maxScale,n-1,i)
            break
        else:
            pid = -1
    return pid

# variables needed for kml doc
image = "http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"

# defining document
doc = KML.Document()

for i in range(0,n):
    size = linterp(minScale,maxScale,n-1,i)
    style = KML.Style(
                KML.IconStyle(
                    KML.scale(size),
                    KML.Icon(
                        KML.href(image),
                    ),
                ),
                id = str(size)
            )
    doc.append(style)

pointfld = KML.Folder()

# looping over the rows in the dataframe
for index, row in nodeData.iterrows():
# reading row information and converting to lat long
    nodeNumStr = str(row[0])
    latlon = OSGB36toWGS84(row[3],row[4])
    latlonStr = str(latlon[1]) + "," + str(latlon[0])
# converting size variable to id
    pid = size2id(row[2])
# creating point and appending to point folder
    point = KML.Placemark(
                KML.name(nodeNumStr),
                KML.styleUrl(str(pid)),
                KML.Point(KML.coordinates(latlonStr))
            )
    pointfld.append(point)

doc.append(pointfld)
kmlDoc = KML.kml(doc)
outfile = file("test.kml",'w')
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()
