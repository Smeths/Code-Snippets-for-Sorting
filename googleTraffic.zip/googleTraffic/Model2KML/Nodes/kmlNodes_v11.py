# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd
import math
from scaleFunctions import *

# opening the node data
nodeData = pd.read_csv('nodeData.csv')

# column numbers
colNode = 0
colName = 1
colX = 2
colY = 3

# Asking user for column require to scale points
print("Select "+str(0)+" not to scale")
for i, col in enumerate(nodeData.columns):
    if i > colY:
        print("Select "+str(i-colY)+" to scale with " + col)
sel = int(raw_input("Selection: "))
colV = sel + colY

# creating breakpoints
n = 101 # number of point sizes
minScale = 0.5
maxScale = 1.5

if sel > 0:
    datamin = math.floor(min(nodeData.iloc[:,colV])) - 1
    datamax = math.ceil(max(nodeData.iloc[:,colV])) + 1
    varBreakPoints = [linterp(datamin,datamax,n,i) for i in range(n+1)]
    scaleBreakPoints = [linterp(minScale,maxScale,n-1,i) for i in range(n)]

# image used as point on map
image = "http://maps.google.com/mapfiles/kml/pal2/icon26.png"
# selecting colour
colour = raw_input("Select node color (6 digit hex code from https://www.w3schools.com/colors/colors_picker.asp): ")
colour = "ff" + colour[::-1]

# defining document
doc = KML.Document()

# defining size styles
if sel > 0:
    for scale in scaleBreakPoints:
        style = KML.Style(
                    KML.IconStyle(
                        KML.color(colour),
                        KML.scale(scale),
                        KML.Icon(
                            KML.href(image),
                        ),
                    ),
                    id = str(scale)
                )
        doc.append(style)
else:
    style = KML.Style(
                KML.IconStyle(
                    KML.color(colour),
                    KML.scale(1.0),
                    KML.Icon(
                        KML.href(image),
                    ),
                ),
                id = str(1.0)
            )
    doc.append(style)    
    
# Creating folder for points
pointfld = KML.Folder()

# looping over the rows in the dataframe
for index, row in nodeData.iterrows():
# reading row information and converting to lat long
    latlon = OSGB36toWGS84(row[colX],row[colY])
    latlonStr = str(latlon[1]) + "," + str(latlon[0])
# converting size variable to id
    if sel > 0:
        pid = Var2ScaleID(row[colV], varBreakPoints, scaleBreakPoints)
    else:
        pid = 1.0
# creating point and appending to point folder
    point = KML.Placemark(
                KML.styleUrl(str(pid)),
                KML.Point(KML.coordinates(latlonStr))
            )
    exData = KML.ExtendedData( 
                KML.Data(KML.value(str(row[colNode])),name="Node Number: ")
             )
    if pd.isnull(row[colName]):
        data = KML.Data(KML.value("not available"),name="Node Name: ")
    else:
        data = KML.Data(KML.value(str(row[colName])),name="Node Name: ")
    exData.append(data)
    
# adding table for remaining data to table for given point
    for i, col in enumerate(nodeData.columns):
        if i > colY:
            if pd.isnull(row[i]):
                data = KML.Data(KML.value("not available"),name=col+": ")
            else:
                data = KML.Data(KML.value(str(row[i])),name=col+": ")                
            exData.append(data)
    point.append(exData)
# Adding point to folder
    pointfld.append(point)

# Adding point folder and producing files
doc.append(pointfld)
kmlDoc = KML.kml(doc)
if sel>0:
    outfile = file("nodes_" + nodeData.columns[colV] + ".kml",'w')
else:
    outfile = file("nodes.kml",'w')    
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()
