# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd

# function for point size
def size2id(sizeVar, breakpoints, pids):
    for i, breakpoint in enumerate(breakpoints):
        if sizeVar > breakpoint and sizeVar < breakpoints[i+1]:
            pid = pids[i]
            break
    return pid


# opening the node data
nodeData = pd.read_csv('nodeData.csv')

# variables needed for kml doc

image = "http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"
sizeIcon = [0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 1.7, 1.9]
pids = ["circp5", "circp7", "circp9", "circ1p1","circ1p3","circ1p5","circ1p7","circ1p9"]
breakpoints = [5000,6000,7000,8000,9000,10000,11000,12000,13000]

# defining document
doc = KML.Document()

for i, size in enumerate(sizeIcon):
    style = KML.Style(
                KML.IconStyle(
                    KML.scale(size),
                    KML.Icon(
                        KML.href(image),
                    ),
                ),
                id = pids[i]
            )
    doc.append(style)

pointfld = KML.Folder()

# looping over the rows in the dataframe
for index, row in nodeData.iterrows():
# reading row information and converting to lat long
    nodeNumStr = str(row[0])
    latlon = OSGB36toWGS84(row[3],row[4])
    latlonStr = str(latlon[1]) + "," + str(latlon[0])
# converting size variable to id
    pid = size2id(row[2],breakpoints,pids)
# creating point and appending to point folder
    point = KML.Placemark(
                KML.name(nodeNumStr),
                KML.styleUrl(pid),
                KML.Point(KML.coordinates(latlonStr))
            )
    pointfld.append(point)

doc.append(pointfld)
kmlDoc = KML.kml(doc)
outfile = file("test.kml",'w')
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()
