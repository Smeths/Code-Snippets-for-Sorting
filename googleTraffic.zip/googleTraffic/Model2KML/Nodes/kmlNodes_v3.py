# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd

# opening the node data
nodeData = pd.read_csv('nodeData.csv') 

# defining styles
doc = KML.Document(
# 0.5 scale circle
              KML.Style(
                  KML.IconStyle(
                      KML.scale(0.5),
                      KML.Icon(
                          KML.href("http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"),
                      ),
                  ),
                  id="circp5"
              ),
# 0.6 scale circle
              KML.Style(
                  KML.IconStyle(
                      KML.scale(0.7),
                      KML.Icon(
                          KML.href("http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"),
                      ),
                  ),
                  id="circp6"
              ),
# 0.7 scale circle
              KML.Style(
                  KML.IconStyle(
                      KML.scale(0.9),
                      KML.Icon(
                          KML.href("http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"),
                      ),
                  ),
                  id="circp7"
              ),
# 0.8 scale circle
              KML.Style(
                  KML.IconStyle(
                      KML.scale(1.1),
                      KML.Icon(
                          KML.href("http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"),
                      ),
                  ),
                  id="circp8"
              ),
# 0.9 scale circle
              KML.Style(
                  KML.IconStyle(
                      KML.scale(1.3),
                      KML.Icon(
                          KML.href("http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"),
                      ),
                  ),
                  id="circp9"
              ),
# 1.0 scale circle
              KML.Style(
                  KML.IconStyle(
                      KML.scale(1.5),
                      KML.Icon(
                          KML.href("http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"),
                      ),
                  ),
                  id="circ1p0"
              ),
# 1.1 scale circle
              KML.Style(
                  KML.IconStyle(
                      KML.scale(1.7),
                      KML.Icon(
                          KML.href("http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"),
                      ),
                  ),
                  id="circ1p1"
              ),
# 1.2 scale circle
              KML.Style(
                  KML.IconStyle(
                      KML.scale(1.9),
                      KML.Icon(
                          KML.href("http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png"),
                      ),
                  ),
                  id="circ1p2"
              )
          )

# looping over the rows in the dataframe
for index, row in nodeData.iterrows():
    nodeNumStr = str(row[0])
    latlon = OSGB36toWGS84(row[3],row[4])
    latlonStr = str(latlon[1]) + "," + str(latlon[0])
    if row[2] < 6000:
        point = KML.Placemark(
                         KML.name(nodeNumStr),
                         KML.styleUrl("#circp5"),
                         KML.Point(KML.coordinates(latlonStr))
                     )
    elif row[2] >= 6000 and row[2] < 7000:
        point = KML.Placemark(
                         KML.name(nodeNumStr),
                         KML.styleUrl("#circp6"),
                         KML.Point(KML.coordinates(latlonStr))
                     )
    elif row[2] >= 7000 and row[2] < 8000:
        point = KML.Placemark(
                         KML.name(nodeNumStr),
                         KML.styleUrl("#circp7"),
                         KML.Point(KML.coordinates(latlonStr))
                     )
    elif row[2] >= 8000 and row[2] < 9000:
        point = KML.Placemark(
                         KML.name(nodeNumStr),
                         KML.styleUrl("#circp8"),
                         KML.Point(KML.coordinates(latlonStr))
                     )
    elif row[2] >= 9000 and row[2] < 10000:
        point = KML.Placemark(
                         KML.name(nodeNumStr),
                         KML.styleUrl("#circp9"),
                         KML.Point(KML.coordinates(latlonStr))
                     )
    elif row[2] >= 10000 and row[2] < 11000:
        point = KML.Placemark(
                         KML.name(nodeNumStr),
                         KML.styleUrl("#circ1p0"),
                         KML.Point(KML.coordinates(latlonStr))
                     )
    elif row[2] >= 11000 and row[2] < 12000:
        point = KML.Placemark(
                         KML.name(nodeNumStr),
                         KML.styleUrl("#circ1p1"),
                         KML.Point(KML.coordinates(latlonStr))
                     )
    elif row[2] >= 12000:
        point = KML.Placemark(
                         KML.name(nodeNumStr),
                         KML.styleUrl("#circ1p2"),
                         KML.Point(KML.coordinates(latlonStr))
                     )

    if index == 0:
        fld = KML.Folder(point)
    else:
        fld.append(point)

# appending folder to document
doc.append(fld)

kmlDoc = KML.kml(doc)
print(etree.tostring(kmlDoc, pretty_print=True).decode())




