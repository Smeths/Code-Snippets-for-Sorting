# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd

# opening the node data
nodeData = pd.read_csv('nodeData.csv') 

# naming object
name_object = KML.name("High Volume Nodes")

# looping over the rows in the dataframe
for index, row in nodeData.iterrows():
    nodeNumStr = str(row[0])
    latlon = OSGB36toWGS84(row[3],row[4])
    latlonStr = str(latlon[1]) + "," + str(latlon[0])
    point = KML.Placemark(
                     KML.name(nodeNumStr),
                     KML.Point(KML.coordinates(latlonStr))
                  )
    if index == 0:
        fld = KML.Folder(point)
    else:
        fld.append(point)

print(etree.tostring(fld, pretty_print=True).decode())


