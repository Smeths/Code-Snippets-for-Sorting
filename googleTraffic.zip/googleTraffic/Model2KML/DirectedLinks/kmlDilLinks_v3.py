# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd
import math
import kmlLinksNoData
from ScaleFromTo import *

# opening the node data
nodeData = pd.read_csv('nodeData.csv')
linkData = pd.read_csv('linkData.csv')

# defining column numbers
colLNum = 0
colLName = 1
colLFromN = 2
colLToN = 3

# Asking user for column require to scale points
for i, col in enumerate(linkData.columns):
    if i > colLToN:
        print("Select "+str(i)+" to scale with " + col)
sel = raw_input("Selection: ")
colV = int(sel)

# creating breakpoints
n = 101 # number of point sizes
minScale = 0.5
maxScale = 1.5
datamin = math.floor(min(linkData.iloc[:,colV])) - 1
datamax = math.ceil(max(linkData.iloc[:,colV])) + 1
varBreakPoints = [linterp(datamin,datamax,n,i) for i in range(n+1)]
scaleBreakPoints = [linterp(minScale,maxScale,n-1,i) for i in range(n)]

styleCount = 10

# defining document
doc = KML.Document()

# Creating folder for points
pointfld = KML.Folder()

# looping over the rows in the dataframe
for index, row in linkData.iterrows():
# extracting from and to coordinates
    fromNodeLog = nodeData.iloc[:,0] == row[colLFromN]
    xFromCoord = nodeData[fromNodeLog].iloc[:,1].values[0]
    yFromCoord = nodeData[fromNodeLog].iloc[:,2].values[0]
    toNodeLog = nodeData.iloc[:,0] == row[colLToN]
    xToCoord = nodeData[toNodeLog].iloc[:,1].values[0]
    yToCoord = nodeData[toNodeLog].iloc[:,2].values[0]

# creating point and corresponding scale
    scale = Var2ScaleID(row[colV], varBreakPoints, scaleBreakPoints)
    [point, style] = fromtoPoint([xFromCoord, yFromCoord],[xToCoord, yToCoord],styleCount,scale)

# adding the style to the document
    doc.append(style)

# appending the extra data to the point
    exData = KML.ExtendedData( 
                KML.Data(KML.value(str(row[colLNum])),name="Link Number: "),
                KML.Data(KML.value(str(row[colLName])),name="Link Name: ")
             )
# adding table for remaining data to table for given point
    for i, col in enumerate(linkData.columns):
        if i > colLToN:
            data = KML.Data(KML.value(str(row[i])),name=col+": ")
            exData.append(data)
    point.append(exData)
    pointfld.append(point)
    styleCount = styleCount + 1

# Adding point folder and producing files
doc.append(pointfld)
kmlDoc = KML.kml(doc)
outfile = file("links_" + linkData.columns[colV] + ".kml",'w')
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()
