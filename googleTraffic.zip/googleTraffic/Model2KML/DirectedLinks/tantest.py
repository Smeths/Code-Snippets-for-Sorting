import math

# checking how tan inverse behaves

x=1
y=1
angle = math.degrees(math.atan(y/x))
print(angle)

x = -1
y = 1
angle = math.degrees(math.atan(y/x))
print(90-angle)

x = -1
y = -1
angle = math.degrees(math.atan(y/x))
print(180+angle)

x = 1
y = -1
angle = math.degrees(math.atan(y/x))
print(360+angle)
