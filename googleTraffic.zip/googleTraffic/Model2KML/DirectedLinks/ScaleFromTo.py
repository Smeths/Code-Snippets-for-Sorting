from pykml.factory import KML_ElementMaker as KML
from bng_to_latlon import OSGB36toWGS84
import math

# returning orientation of arrow
def arrowangle(x,y):
    if x != 0 and y != 0:
        angle = math.degrees(math.atan(y/x))
# dealing with special cases of x and/or y equal to 0
    elif x != 0 and y==0:
        if x > 0:
            angle = 0
        else:
            angle = 180
    elif x == 0 and y != 0:
        if y > 0:
            angle = 90
        else:
            angle = 270
    else:
        angle = 270
# calculating angle between 0 and 360
    if x >= 0 and y >= 0:
        angle = angle
    elif x <= 0 and y >= 0:
        angle = 180 + angle
    elif x <= 0 and y <= 0:
        angle =  180 + angle
    elif x >= 0 and y <= 0:
        angle =  angle + 360
    angle = 270 - angle
    return angle

# function for linear interpolation
def linterp(minp, maxp,n,i):
    return (minp*(n-i) + maxp*i)/n

# function for point size
def Var2ScaleID(var,varBreakPoints,scaleBreakPoints):
    for i, breakpoint in enumerate(varBreakPoints):
        if var >= breakpoint and var <= varBreakPoints[i+1]:
            ScaleID = scaleBreakPoints[i]
            break
        else:
            ScaleID = -100
    return ScaleID

# returns style and point for from to
def fromtoPoint(fromcoord, tocoord, styleCount,scale,colour):
    # finding coords of point 75% along from to line
    arrowProp = 0.75
    imageArrow = "http://maps.google.com/mapfiles/kml/shapes/arrow.png"
    xdir = fromcoord[0] + arrowProp*(tocoord[0] - fromcoord[0])
    ydir = fromcoord[1] + arrowProp*(tocoord[1] - fromcoord[1])
    latlon = OSGB36toWGS84(xdir,ydir)
    latlonStr = str(latlon[1]) + "," + str(latlon[0])

    # creating point
    point = KML.Placemark(
                KML.styleUrl(str(styleCount)),
                KML.Point(KML.coordinates(latlonStr))
            )
    # finding angle for style
    angle = arrowangle(tocoord[0] - fromcoord[0],tocoord[1] - fromcoord[1])
    style = KML.Style(
            KML.IconStyle(
                KML.color(colour),
                KML.scale(scale),
                KML.Icon(
                    KML.href(imageArrow),
                ),
            KML.heading(angle)
            ),
            id = str(styleCount)
        )
    return [point, style]
