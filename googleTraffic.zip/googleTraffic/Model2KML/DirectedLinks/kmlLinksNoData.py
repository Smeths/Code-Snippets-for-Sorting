# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd
import math
from ScaleFromTo import *

# opening the node data
nodeData = pd.read_csv('nodeData.csv')
linkData = pd.read_csv('linkData.csv')

# inserting x and y coords for from and to nodes
linkDataEven = linkData[linkData.index.values % 2==0].reset_index(drop=True)
linkFromNodes = linkDataEven.iloc[:,0:4].merge(nodeData,
                                               left_on=linkDataEven.columns[2],
                                               right_on=nodeData.columns[0])
linkFromToNodes = linkFromNodes.merge(nodeData,
                                      left_on=linkFromNodes.columns[3],
                                      right_on=nodeData.columns[0])
linkFromToNodes.drop([linkFromToNodes.columns[4],linkFromToNodes.columns[7]], axis=1, inplace=True)
scale = 5

# column numbers
colLink = 0
colName = 1
colFNode = 2
colTNode = 3
colFX = 4
colFY = 5
colTX = 6
colTY = 7

# defining document
doc = KML.Document()

# defining size styles
style = KML.Style(
            KML.LineStyle(
                KML.width(scale)
            ),
            id = str(scale)
        )
doc.append(style)

# Creating folder for points
linefld = KML.Folder()

# looping over the rows in the dataframe
for index, row in linkFromToNodes.iterrows():
# reading row information and converting to lat long
    linkNumStr = str(row[colLink])
    latlonF = OSGB36toWGS84(row[colFX],row[colFY])
    latlonFStr = str(latlonF[1]) + "," + str(latlonF[0]) + " "
    latlonT = OSGB36toWGS84(row[colTX],row[colTY])
    latlonTStr = str(latlonT[1]) + "," + str(latlonT[0])
    latlonStr = latlonFStr + latlonTStr
# creating point and appending to point folder
    line = KML.Placemark(
               KML.name(linkNumStr),
               KML.styleUrl(str(scale)),
               KML.LineString(KML.coordinates(latlonStr))
           )
    exData = KML.ExtendedData( 
                KML.Data(KML.value(linkNumStr),name="Link Number: "),
                KML.Data(KML.value(str(row[colName])),name="Link Name: ")
             )
# adding name and number data for each link
    line.append(exData)
# Adding point to folder
    linefld.append(line)

# Adding point folder and producing files
doc.append(linefld)
kmlDoc = KML.kml(doc)
outfile = file("links.kml",'w')
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()








