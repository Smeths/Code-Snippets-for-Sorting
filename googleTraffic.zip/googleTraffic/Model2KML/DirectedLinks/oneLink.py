# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd
import math

def ang0to360(x,y):
    angle = math.degrees(math.atan(y/x))
    print(x)
    print(y)
    if x >= 0 and y >= 0:
        return angle
    elif x <= 0 and y >= 0:
        return 90 - angle
    elif x <= 0 and y <= 0:
        return 180 + angle
    elif x >= 0 and y <= 0:
        return angle + 360

def fromtoPoint(fromcoord, tocoord, fromtoData, styleCount):
    # finding coords of point 75% along from to line
    arrowProp = 0.75
    xdir = fromcoord[0] + arrowProp*(tocoord[0] - fromcoord[0])
    ydir = fromcoord[1] + arrowProp*(tocoord[1] - fromcoord[1])
    latlon = OSGB36toWGS84(xdir,ydir)
    latlonStr = str(latlon[1]) + "," + str(latlon[0])
    # selecting arrow image to use
    imageArrow = "http://maps.google.com/mapfiles/kml/shapes/arrow.png"
    # creating point
    point = KML.Placemark(
                KML.styleUrl(str(styleCount)),
                KML.Point(KML.coordinates(latlonStr))
            )
    # finding angle for style
    angle = ang0to360(tocoord[0] - fromcoord[0],tocoord[1] - fromcoord[1])
    style = KML.Style(
            KML.IconStyle(
                KML.scale(1.0),
                KML.Icon(
                    KML.href(imageArrow),
                ),
            KML.heading(270.0 - angle)
            ),
            id = str(styleCount)
        )
    return [point, style]

def fromtoLine(fromcoord, tocoord):
    latlonfrom = OSGB36toWGS84(fromcoord[0],fromcoord[1])
    latlonfromStr = str(latlonfrom[1]) + "," + str(latlonfrom[0])
    latlonto = OSGB36toWGS84(tocoord[0],tocoord[1])
    latlontoStr = str(latlonto[1]) + "," + str(latlonto[0])
    latlonStr = latlonfromStr + " " + latlontoStr
    line = KML.Placemark(
                  KML.LineString(
                      KML.coordinates(
                          latlonStr
                      )
                  )
              )
    return line

# program to demonstrate direction approach

# defining document
doc = KML.Document()

nodeData = pd.read_csv('nodeData_one.csv')
linkData = pd.read_csv('linkData_one.csv')

# reading link row
linkRowNum = 0
fromNode = linkData.iloc[linkRowNum,1]
toNode = linkData.iloc[linkRowNum,2]
fromtoData = linkData.iloc[linkRowNum,4]

# finding from node x and y coords

fromNodeSer = nodeData.iloc[:,0] == fromNode
fromNodeInd = fromNodeSer[fromNodeSer].index[0]
[xfrom,yfrom] = [nodeData.iloc[fromNodeInd,2],nodeData.iloc[fromNodeInd,3]]

# finding to node x and y coords

toNodeSer = nodeData.iloc[:,0] == toNode
toNodeInd = toNodeSer[toNodeSer].index[0]
[xto,yto] = [nodeData.iloc[toNodeInd,2],nodeData.iloc[toNodeInd,3]]

[point,style] = fromtoPoint([xfrom,yfrom],[xto,yto],fromtoData,linkRowNum)
line = fromtoLine([xfrom,yfrom],[xto,yto])
doc.append(style)
doc.append(point)
doc.append(line)

kmlDoc = KML.kml(doc)
outfile = file("test.kml",'w')
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()




