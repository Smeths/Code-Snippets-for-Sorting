# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd
import math
import kmlLinksNoData
from ScaleFromTo import *

# opening the node data
nodeData = pd.read_csv('nodeData.csv')
linkData = pd.read_csv('linkData.csv')

# defining column numbers
colLNum = 0
colLName = 1
colLFromN = 2
colLToN = 3

# Asking user for column require to scale points
print("Select "+str(0)+" not to scale")
for i, col in enumerate(linkData.columns):
    if i > colLToN:
        print("Select "+str(i-colLToN)+" to scale with " + col)
sel = int(raw_input("Selection: "))
colV = sel + colLToN

# creating breakpoints
n = 101 # number of point sizes
minScale = 0.5
defScale = 1.0
maxScale = 1.5
if sel > 0:
    datamin = math.floor(min(linkData.iloc[:,colV])) - 1
    datamax = math.ceil(max(linkData.iloc[:,colV])) + 1
    varBreakPoints = [linterp(datamin,datamax,n,i) for i in range(n+1)]
    scaleBreakPoints = [linterp(minScale,maxScale,n-1,i) for i in range(n)]

# Selecting colour
colour = raw_input("Select node color (6 digit hex code from https://www.w3schools.com/colors/colors_picker.asp): ")
colour = "ff" + colour[::-1]

styleCount = 10

# defining document
doc = KML.Document()

# Creating folder for points
pointfld = KML.Folder()

# looping over the rows in the dataframe
for index, row in linkData.iterrows():
# extracting from and to coordinates
    fromNodeLog = nodeData.iloc[:,0] == row[colLFromN]
    xFromCoord = nodeData[fromNodeLog].iloc[:,1].values[0]
    yFromCoord = nodeData[fromNodeLog].iloc[:,2].values[0]
    toNodeLog = nodeData.iloc[:,0] == row[colLToN]
    xToCoord = nodeData[toNodeLog].iloc[:,1].values[0]
    yToCoord = nodeData[toNodeLog].iloc[:,2].values[0]

# creating point and corresponding scale
    if sel > 0:
        scale = Var2ScaleID(row[colV], varBreakPoints, scaleBreakPoints)
    else:
        scale = defScale
    [point, style] = fromtoPoint([xFromCoord, yFromCoord],[xToCoord, yToCoord],styleCount,scale,colour)
# adding the style to the document
    doc.append(style)

# appending the extra data to the point
    exData = KML.ExtendedData( 
                KML.Data(KML.value(str(row[colLNum])),name="Link Number: ")
             )
    if pd.isnull(row[colLName]):
        data = KML.Data(KML.value("not available"),name="Link Name: ")
    else:
        data = KML.Data(KML.value(str(row[colLName])),name="Link Name: ")
    exData.append(data)
# adding table for remaining data to table for given point
    for i, col in enumerate(linkData.columns):
        if i > colLToN:
            if pd.isnull(row[i]):
                data = KML.Data(KML.value("not available"),name=col+": ")
            else:
                data = KML.Data(KML.value(str(row[i])),name=col+": ")                
            exData.append(data)
    point.append(exData)
    pointfld.append(point)
    styleCount = styleCount + 1

# Adding point folder and producing files
doc.append(pointfld)
kmlDoc = KML.kml(doc)
if sel >0:
    outfile = file("links_" + linkData.columns[colV] + ".kml",'w')
else:
    outfile = file("links_noscale.kml",'w')    
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()
