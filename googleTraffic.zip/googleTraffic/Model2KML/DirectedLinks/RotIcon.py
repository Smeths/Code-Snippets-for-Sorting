# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import math
import pandas as pd

image = "http://maps.google.com/mapfiles/kml/shapes/arrow.png"

def ang0to360(x,y):
    angle = math.degrees(math.atan(y/x))
    if x >= 0 and y >= 0:
        return angle
    elif x <= 0 and y >= 0:
        return 90 - angle
    elif x <= 0 and y <= 0:
        return 180 + angle
    elif x >= 0 and y <= 0:
        return angle + 360
    

# defining document
doc = KML.Document()

style = KML.Style(
            KML.IconStyle(
                KML.scale(1.0),
                KML.Icon(
                    KML.href(image),
                ),
            KML.heading(-90)
            ),
            id = "arrow"
        )
doc.append(style)

pm1 = KML.Placemark(
          KML.styleUrl("arrow"),
          KML.Point(
              KML.coordinates("-64.5253,18.4607")
          ),
      )
doc.append(pm1)

kmlDoc = KML.kml(doc)
outfile = file("test.kml",'w')
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()
