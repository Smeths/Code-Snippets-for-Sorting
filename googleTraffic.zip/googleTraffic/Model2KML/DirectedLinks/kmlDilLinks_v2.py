# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd
import math
from ScaleFromTo import *

# opening the node data
nodeData = pd.read_csv('nodeData_mini.csv')
linkData = pd.read_csv('linkData_mini.csv')

# defining column numbers
colLNum = 0
colLName = 1
colLFromN = 2
colLToN = 3

styleCount = 10

# defining document
doc = KML.Document()

# Creating folder for points
pointfld = KML.Folder()

# looping over the rows in the dataframe
for index, row in linkData.iterrows():
    fromNodeLog = nodeData.iloc[:,0] == row[colLFromN]
    xFromCoord = nodeData[fromNodeLog].iloc[:,1].values[0]
    yFromCoord = nodeData[fromNodeLog].iloc[:,2].values[0]
    toNodeLog = nodeData.iloc[:,0] == row[colLToN]
    xToCoord = nodeData[toNodeLog].iloc[:,1].values[0]
    yToCoord = nodeData[toNodeLog].iloc[:,2].values[0]
    [point, style] = fromtoPoint([xFromCoord, yFromCoord],[xToCoord, yToCoord],styleCount,(index+1)*0.1)
    doc.append(style)
    pointfld.append(point)
    styleCount = styleCount + 1

# Adding point folder and producing files
doc.append(pointfld)
kmlDoc = KML.kml(doc)
outfile = file("links_" + ".kml",'w')
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()
