# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd
import math
from scaleFunctions import *

# opening the node data
nodeData = pd.read_csv('nodeData.csv')
linkData = pd.read_csv('linkData.csv')

# adding odd and even rows together
linkDataEven = linkData[linkData.index.values % 2==0].reset_index(drop=True)
linkDataOdd = linkData[linkData.index.values % 2==1].reset_index(drop=True)
linkDataAddData = linkDataEven.iloc[:,4:] + linkDataOdd.iloc[:,4:]

# inserting x and y coords for from and to nodes
linkFromNodes = linkDataEven.iloc[:,0:3].merge(nodeData,
                                               left_on=linkDataEven.columns[1],
                                               right_on=nodeData.columns[0])
linkFromToNodes = linkFromNodes.merge(nodeData,
                                      left_on=linkFromNodes.columns[2],
                                      right_on=nodeData.columns[0])
linkFromToNodes.drop([linkFromToNodes.columns[3],linkFromToNodes.columns[6]], axis=1, inplace=True)

# combining coordinates and data
linkDataAdd = pd.concat([linkFromToNodes,linkDataAddData],axis=1)






