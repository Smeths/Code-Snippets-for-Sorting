# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd

# defining document
doc = KML.Document()

style1 = KML.Style(
             KML.LineStyle(
                 KML.width(1)
             ),
             id = "size1"
         )

doc.append(style1)

style10 = KML.Style(
              KML.LineStyle(
                 KML.width(10)
              ),
              id = "size10"
          )

doc.append(style10)
    
fld = KML.Folder()

linestring1 = KML.Placemark(
                  KML.LineString(
                      KML.coordinates(
                          "146.825,12.233 " "146.820,12.222"
                      )
                  ),
                  KML.styleUrl("size1"),
              )

fld.append(linestring1)

linestring2 = KML.Placemark(
                  KML.LineString(
                      KML.coordinates(
                          "146.825,12.233 " "146.828,12.226"
                      )
                  ),
                  KML.styleUrl("size10"),
              )

fld.append(linestring2)

doc.append(fld)
kmlDoc = KML.kml(doc)
outfile = file("test.kml",'w')
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()
