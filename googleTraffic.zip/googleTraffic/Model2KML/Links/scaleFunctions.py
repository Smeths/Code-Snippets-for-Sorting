# function for linear interpolation
def linterp(minp, maxp,n,i):
    return (minp*(n-i) + maxp*i)/n

# function for point size
def Var2ScaleID(var,varBreakPoints,scaleBreakPoints):
    for i, breakpoint in enumerate(varBreakPoints):
        if var >= breakpoint and var <= varBreakPoints[i+1]:
            ScaleID = scaleBreakPoints[i]
            break
        else:
            ScaleID = -100
    return ScaleID
