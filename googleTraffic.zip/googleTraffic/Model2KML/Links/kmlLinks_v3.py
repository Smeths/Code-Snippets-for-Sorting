# Importing packages needed
from pykml.factory import ATOM_ElementMaker as ATOM
from pykml.factory import GX_ElementMaker as GX
from pykml.factory import KML_ElementMaker as KML
from lxml import etree
from bng_to_latlon import OSGB36toWGS84
import pandas as pd
import math
from scaleFunctions import *

# opening the node data
nodeData = pd.read_csv('nodeData.csv')
linkData = pd.read_csv('linkData.csv')

# adding odd and even rows together
linkDataEven = linkData[linkData.index.values % 2==0].reset_index(drop=True)
linkDataOdd = linkData[linkData.index.values % 2==1].reset_index(drop=True)
linkDataAddData = linkDataEven.iloc[:,4:] + linkDataOdd.iloc[:,4:]

# inserting x and y coords for from and to nodes
linkFromNodes = linkDataEven.iloc[:,0:4].merge(nodeData,
                                               left_on=linkDataEven.columns[2],
                                               right_on=nodeData.columns[0])
linkFromToNodes = linkFromNodes.merge(nodeData,
                                      left_on=linkFromNodes.columns[3],
                                      right_on=nodeData.columns[0])
linkFromToNodes.drop([linkFromToNodes.columns[4],linkFromToNodes.columns[7]], axis=1, inplace=True)

# combining coordinates and data
linkDataAdd = pd.concat([linkFromToNodes,linkDataAddData],axis=1)

# creating breakpoints
n = 101 # number of point sizes
minScale = 5
maxScale = 25

# column numbers
colLink = 0
colName = 1
colFNode = 2
colTNode = 3
colFX = 4
colFY = 5
colTX = 6
colTY = 7

# Asking user for column require to scale points
for i, col in enumerate(linkDataAdd.columns):
    if i > colTY:
        print("Select "+str(i)+" to scale with " + col)
sel = raw_input("Selection: ")
colV = int(sel)

datamin = math.floor(min(linkDataAdd.iloc[:,colV])) - 1
datamax = math.ceil(max(linkDataAdd.iloc[:,colV])) + 1
varBreakPoints = [linterp(datamin,datamax,n,i) for i in range(n+1)]
scaleBreakPoints = [linterp(minScale,maxScale,n-1,i) for i in range(n)]

# defining document
doc = KML.Document()

# defining size styles
for scale in scaleBreakPoints:
    style = KML.Style(
                KML.LineStyle(
                    KML.width(scale)
                ),
                id = str(scale)
            )
    doc.append(style)

# Creating folder for points
linefld = KML.Folder()

# looping over the rows in the dataframe
for index, row in linkDataAdd.iterrows():
# reading row information and converting to lat long
    linkNumStr = str(row[colLink])
    latlonF = OSGB36toWGS84(row[colFX],row[colFY])
    latlonFStr = str(latlonF[1]) + "," + str(latlonF[0]) + " "
    latlonT = OSGB36toWGS84(row[colTX],row[colTY])
    latlonTStr = str(latlonT[1]) + "," + str(latlonT[0])
    latlonStr = latlonFStr + latlonTStr
# converting size variable to id
    pid = Var2ScaleID(row[colV], varBreakPoints, scaleBreakPoints)
# creating point and appending to point folder
    line = KML.Placemark(
               KML.name(linkNumStr),
               KML.styleUrl(str(pid)),
               KML.LineString(KML.coordinates(latlonStr))
           )
    exData = KML.ExtendedData( 
                KML.Data(KML.value(linkNumStr),name="Link Number: "),
                KML.Data(KML.value(str(row[colName])),name="Link Name: ")
             )
# adding table for remaining data to table for given point
    for i, col in enumerate(linkDataAdd.columns):
        if i > colTY:
            data = KML.Data(KML.value(str(row[i])),name=col+": ")
            exData.append(data)
    line.append(exData)
# Adding point to folder
    linefld.append(line)

# Adding point folder and producing files
doc.append(linefld)
kmlDoc = KML.kml(doc)
outfile = file("links_" + linkDataAdd.columns[colV] + ".kml",'w')
outfile.write(etree.tostring(kmlDoc, pretty_print=True).decode())
outfile.close()








