param(
    [String] $amfile,
    [String] $ipfile,
    [String] $pmfile
)
./AADT_extraction.bat "$amfile" "$ipfile" "$pmfile"
./chopFile.ps1 -ipfile ($amfile + ".CBA") -opfile "AADT_output.CBA" -topStr "FLOW ON" -topOffset 0 -botStr "URBAN ROAD" -botOffset -2
