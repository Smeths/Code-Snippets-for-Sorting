$scens=@('base','DM_2028','DM_2043','DM_2058','DS_2028','DS_2043','DS_2058')
$mods=@('AM22_Post', 'IP22_Post', 'PM22_Post',
        'AM22_Post', 'IP22_Post', 'PM22_Post',
        'AM22_Post', 'IP22_Post', 'PM22_Post',
		'AM22_Post', 'IP22_Post', 'PM22_Post',
		'AM22_Post', 'IP22_Post', 'PM22_Post',
		'AM22_Post', 'IP22_Post', 'PM22_Post',
		'AM22_Post', 'IP22_Post', 'PM22_Post')
for ($num = 0; $num -lt 7; $num++) {
    xcopy "extractAADT\*" $scens[$num] /Y
	cd $scens[$num]
	./AADT_extraction.ps1 -amfile $mods[3*$num] -ipfile $mods[3*$num+1] -pmfile $mods[3*$num+2] 
    cd ..	
}
