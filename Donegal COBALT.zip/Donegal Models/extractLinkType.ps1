$scens=@('base', 'DM_2028', 'DS_2028')
$amMods=@('AM22_Post', 'AM22_Post', 'AM22_Post')

for ($num = 0; $num -lt 3; $num++) {
    xcopy "extractLinkType\*" $scens[$num] /Y
	cd $scens[$num]
	./link_type_extraction.bat $amMods[$num] 
    cd ..	
}
