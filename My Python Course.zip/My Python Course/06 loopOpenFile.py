# import libraries
import os
import numpy as np
    
# looping over subdirectories and files
dir = os.getcwd()
dataDir = os.path.join(dir,'actual')
for subdir, dirs, files in os.walk(dataDir):
    for filename in files:
        if filename[-4:] == ".csv" and filename[0:3] == "Car":
            file = os.path.join(subdir,filename)
            data = np.loadtxt(file,skiprows=13,max_rows=988036)
            year = subdir.replace(dataDir+'\\','')
            print(filename)
            print(data[:,2].sum())

