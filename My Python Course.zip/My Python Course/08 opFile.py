# import libraries
import os
import numpy as np

# function to calculate costs
def calcStats(data,filename,year,opFile):
    costs = ["IT0","ITA","IFW","IMA"]
    opline = year + "," + filename
    for i, cost in enumerate(costs):
        opline = opline + "," + str(data[:,i+2].sum())
    opline = opline + "\n"
    opFile.write(opline)    
    
# looping over subdirectories and files
dir = os.getcwd()
opFile = open("costAnalysis.csv","w")
opFile.write("year,scenario,IT0,ITA,IFW,IMA \n")
dataDir = os.path.join(dir,'actual')
for subdir, dirs, files in os.walk(dataDir):
    for filename in files:
        if filename[-4:] == ".csv" and filename[0:3] == "Car":
            print(filename)
            file = os.path.join(subdir,filename)
            data = np.loadtxt(file,skiprows=13,max_rows=988036)
            year = subdir.replace(dataDir+'\\','')
            calcStats(data,filename,year,opFile)
opFile.close()

