# import libraries
import os
import numpy as np
# looping over files in a directory
dir = os.getcwd()
print(dir)


