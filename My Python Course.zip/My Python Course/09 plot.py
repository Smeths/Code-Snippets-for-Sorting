# import libraries
import os
import numpy as np
import sys
sys.path.append(r'C:\Program Files\PTV Vision\PTV Visum 17\Exe\PythonModules')
import matplotlib
import matplotlib.pyplot as plt

file = "actual\Car 2036\Car_Biz_AM.csv"
data = np.loadtxt(file,skiprows=13,max_rows=988036)
ita = data[:,3]
ita = ita.reshape(994,994)
fig, ax = plt.subplots()
ax.imshow(ita)
plt.show()




