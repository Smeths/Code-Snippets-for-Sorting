# import libraries
import os
import sys
import numpy as np

def calcStats(data,filename,year):
    costs = ["IT0","ITA","IFW","IMA"]
    opline = year + "," + filename
    for i, cost in enumerate(costs):
        opline = opline + "," + str(data[:,i+2].sum())
    print(opline)
    
# looping over subdirectories and files
dir = os.getcwd()
dataDir = os.path.join(dir,'actual')
for subdir, dirs, files in os.walk(dataDir):
    for filename in files:
        if filename[-4:] == ".csv" and filename[0:3] == "Car":
            file = os.path.join(subdir,filename)
            data = np.loadtxt(file,skiprows=13,max_rows=988036)
            year = subdir.replace(dataDir+'\\','')
            calcStats(data,filename,year)

