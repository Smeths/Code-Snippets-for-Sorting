# import libraries
import os
import numpy as np
# looping over subdirectories and files
dir = os.getcwd()
dataDir = os.path.join(dir,'actual')
for subdir, dirs, files in os.walk(dataDir):
    print("Start of Loop")
    print(subdir)
    print(dirs)
    print(files)




