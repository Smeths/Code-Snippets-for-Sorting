# import libraries
import os
import numpy as np
# looping over subdirectories and files
dir = os.getcwd()
dataDir = os.path.join(dir,'actual')
for subdir, dirs, files in os.walk(dataDir):
    for filename in files:
        print("start of loop")
        print(subdir)
        print(subdir.replace(dataDir+'\\',''))
        print(filename)

